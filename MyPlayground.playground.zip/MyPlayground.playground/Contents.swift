// Protocol for managing the water system
protocol WaterSystem {
    var waterLevel: Int { get set }
    func fillWaterTank()
}

// Protocol for managing the electricity system
protocol ElectricitySystem {
    var batteryLevel: Int { get set }
    func chargeBattery()
}

// Class representing a camping trailer that conforms to WaterSystem and ElectricitySystem protocols
class CampingTrailer: WaterSystem, ElectricitySystem {
    var waterLevel: Int
    var batteryLevel: Int
    
    init(waterLevel: Int, batteryLevel: Int) {
        self.waterLevel = waterLevel
        self.batteryLevel = batteryLevel
    }
    
    func fillWaterTank() {
        waterLevel = 100 // Filling the water tank to full capacity
        print("Water tank filled.")
    }
    
    func chargeBattery() {
        batteryLevel = 100 // Charging the battery to full capacity
        print("Battery charged.")
    }
}

// Class representing a Camper that conforms to WaterSystem and ElectricitySystem protocols
class Camper: WaterSystem, ElectricitySystem {
    var waterLevel: Int
    var batteryLevel: Int
    
    init(waterLevel: Int, batteryLevel: Int) {
        self.waterLevel = waterLevel
        self.batteryLevel = batteryLevel
    }
    
    func fillWaterTank() {
        waterLevel = 90 // Filling the water tank to 90% capacity for a camper
        print("Water tank filled to 90%.")
    }
    
    func chargeBattery() {
        batteryLevel = 80 // Charging the battery to 80% capacity for a camper
        print("Battery charged to 80%.")
    }
}

// Example usage
let campingTrailer = CampingTrailer(waterLevel: 0, batteryLevel: 0)
campingTrailer.fillWaterTank()
campingTrailer.chargeBattery()

let camper = Camper(waterLevel: 0, batteryLevel: 0)
camper.fillWaterTank()
camper.chargeBattery()
